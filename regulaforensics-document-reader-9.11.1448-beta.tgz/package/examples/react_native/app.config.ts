import { ExpoConfig, ConfigContext } from 'expo/config'

export default ({ config }: ConfigContext): ExpoConfig => ({
  ...config,
  slug: 'document-reader',
  name: 'Document',
  orientation: 'portrait',
  icon: 'images/icon.png',
  ios: {
    bundleIdentifier: 'com.regula.example.dr.react',
    infoPlist: {
      NSCameraUsageDescription: 'To use camera',
      NSPhotoLibraryUsageDescription: 'To use gallery',
      NFCReaderUsageDescription: 'To use NFC',
      NSBluetoothAlwaysUsageDescription: 'To use bluetooth',
      'com.apple.developer.nfc.readersession.iso7816.select-identifiers': [
        'A0000002471001',
        'E80704007F00070302',
        'A000000167455349474E',
        'A0000002480100',
        'A0000002480200',
        'A0000002480300',
        'A0000002480400',
        'A00000045645444C2D3031',
        'D2760000850101',
      ]
    },
    entitlements: { 'com.apple.developer.nfc.readersession.formats': ['TAG'] },
    appleTeamId: ''
  },
  android: {
    package: 'com.regula.example.dr.react',
    permissions: [
      'android.permission.BLUETOOTH_CONNECT',
      'android.permission.NFC']
  },
  plugins: [
    '@regulaforensics/document-reader',
    './scripts/withoutMetroServer',
    ['expo-custom-assets', { assetsPaths: ['./assets'] }],
    ['expo-build-properties', {
      ios: { networkInspector: false },
      android: {
        networkInspector: false,
        extraMavenRepos: [
          { url: 'https://maven.regulaforensics.com/RegulaDocumentReader' },
          { url: 'https://maven.regulaforensics.com/RegulaDocumentReader/Beta' },
          { url: 'https://maven.regulaforensics.com/RegulaDocumentReader/Nightly' },
          { url: 'https://maven.regulaforensics.com/RegulaDocumentReader/Stage' }
        ]
      }
    }]
  ]
})
