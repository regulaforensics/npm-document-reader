@file:Suppress("unused", "UNUSED_PARAMETER")

package com.regula.plugin.document.reader

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import com.facebook.react.ReactPackage
import com.facebook.react.bridge.ActivityEventListener
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.ReadableArray
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.facebook.react.modules.core.PermissionAwareActivity
import com.facebook.react.uimanager.ViewManager
import org.json.JSONArray
import org.json.JSONObject

var listenerCount = 0

lateinit var args: JSONArray
lateinit var binding: ReactContext
val context: Context
    get() = binding.applicationContext
val activity: Activity
    get() = binding.currentActivity!!
val lifecycle: Lifecycle
    get() = (activity as AppCompatActivity).lifecycle

fun sendEvent(event: String, data: Any? = "") {
    if (listenerCount <= 0) return
    val result = if (data is JSONObject || data is JSONArray) data.toString() else data.toString() + ""
    binding.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java).emit(event, result)
}

@Suppress("UNCHECKED_CAST")
fun <T> argsNullable(index: Int): T? {
    val value = args[index]
    if (value is Double && value % 1 == 0.0) return value.toInt() as T
    if (value.toString() == "null") return null
    return value as T
}

fun requestPermissions(activity: Activity, permissions: Array<String>, requestCode: Int) {
    (activity as PermissionAwareActivity).requestPermissions(permissions, requestCode) { code, perms, grantResults ->
        onRequestPermissionsResult(code, perms, grantResults)
    }
}

fun startActivityForResult(activity: Activity, intent: Intent, requestCode: Int) {
    activity.startActivityForResult(intent, requestCode)
}

class RNDocumentReaderPackage : ReactPackage {
    override fun createNativeModules(reactContext: ReactApplicationContext) = listOf(RNDocumentReaderModule(reactContext))
    override fun createViewManagers(reactContext: ReactApplicationContext) = emptyList<ViewManager<*, *>>()
}

class RNDocumentReaderModule(reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext), ActivityEventListener {
    init {
        binding = reactContext
        binding.addActivityEventListener(this)
    }

    @ReactMethod
    fun addListener(eventName: String) {
        listenerCount += 1
    }

    @ReactMethod
    fun removeListeners(count: Int) {
        listenerCount -= count
    }

    override fun onNewIntent(intent: Intent) {
        newIntent(intent)
    }

    override fun onActivityResult(activity: Activity, requestCode: Int, resultCode: Int, data: Intent?) {
        onActivityResult(requestCode, resultCode, data)
    }

    @ReactMethod
    fun exec(method: String, arguments: ReadableArray, promise: Promise) {
        args = JSONArray(arguments.toArrayList())
        try {
            methodCall(method) { data -> promise.resolve(data.toSendable()) }
        } catch (error: Throwable) {
            Log.e("REGULA", "Caught an exception in \"$method\" function:", error)
            promise.reject(Throwable("Unexpected error, check logs for details"))
        }
    }

    override fun getName() = "RNDocumentReader"
}
